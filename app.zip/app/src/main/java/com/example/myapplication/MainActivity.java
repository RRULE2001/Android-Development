package com.example.myapplication;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;


import android.widget.Button;
import android.graphics.Color;
import android.media.MediaPlayer;

public class MainActivity extends AppCompatActivity {

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        Button button = new Button(this);
        button.setBackgroundColor(Color.YELLOW);
        button.setTextColor(Color.BLUE);
        button.setText("MUCH WOW!");
        setContentView(button);

        MediaPlayer mediaplayer = MediaPlayer.create(this,R.raw.fart);


        //MediaPlayer mediaPlayer = MediaPlayer.create(this, R.raw.("res/raw/Fart.mp3"));
        //mediaPlayer.start(); // no need to call prepare(); create() does that for you

        button.setOnClickListener(new View.OnClickListener()
        {
            int i = 2;
            public void onClick(View button)
            {
                mediaplayer.start(); // no need to call prepare(); create() does that for you

                // Do something in response to button click
                if(i%2 == 0)
                {
                    button.setBackgroundColor(Color.RED); // Sets background color to red
                    i++;
                }
                else
                {
                    button.setBackgroundColor(Color.YELLOW); // Sets background color to red
                    i++;
                }



            }
        });
    }

}